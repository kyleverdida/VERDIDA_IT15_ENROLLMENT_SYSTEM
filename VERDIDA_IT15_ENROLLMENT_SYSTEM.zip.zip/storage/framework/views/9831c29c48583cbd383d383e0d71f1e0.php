

<?php $__env->startSection('title', $student->full_name . ' - Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <a href="<?php echo e(route('students.index')); ?>" class="text-red-800 hover:text-red-900 flex items-center">
        <svg class="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
        Back to Students
    </a>
</div>

<div class="bg-white rounded-lg shadow-lg p-8 mb-8">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800"><?php echo e($student->full_name); ?></h1>
            <p class="text-gray-600 mt-1">Student Number: <span class="font-semibold"><?php echo e($student->student_number); ?></span></p>
        </div>
        <div class="text-right">
            <p class="text-gray-600">Email</p>
            <p class="font-semibold text-gray-800"><?php echo e($student->email); ?></p>
        </div>
    </div>

    <div class="border-t pt-6">
        <div class="grid grid-cols-3 gap-4 text-center">
            <div class="bg-red-50 rounded-lg p-4">
                <p class="text-2xl font-bold text-red-800"><?php echo e($student->courses->count()); ?></p>
                <p class="text-gray-600 text-sm">Enrolled Courses</p>
            </div>
            <div class="bg-green-50 rounded-lg p-4">
                <p class="text-2xl font-bold text-green-600"><?php echo e($availableCourses->count()); ?></p>
                <p class="text-gray-600 text-sm">Available Courses</p>
            </div>
            <div class="bg-gray-50 rounded-lg p-4">
                <p class="text-2xl font-bold text-gray-600"><?php echo e($student->created_at->format('M d, Y')); ?></p>
                <p class="text-gray-600 text-sm">Registered Date</p>
            </div>
        </div>
    </div>
</div>

<div class="bg-white rounded-lg shadow-lg p-6 mb-8">
    <h2 class="text-2xl font-bold text-gray-800 mb-4">Enrolled Courses</h2>
    
    <?php if($student->courses->isEmpty()): ?>
        <p class="text-gray-500 text-center py-8">Not enrolled in any courses yet.</p>
    <?php else: ?>
        <div class="grid gap-4">
            <?php $__currentLoopData = $student->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border rounded-lg p-4 hover:shadow-md transition flex justify-between items-center">
                    <div>
                        <h3 class="font-semibold text-lg text-gray-800"><?php echo e($course->course_name); ?></h3>
                        <p class="text-gray-600"><?php echo e($course->course_code); ?></p>
                        <p class="text-sm text-gray-500 mt-1">
                            Enrolled: <?php echo e($course->students->count()); ?> / <?php echo e($course->capacity); ?> students
                        </p>
                    </div>
                    <div class="flex items-center space-x-3">
                        <a href="<?php echo e(route('courses.show', $course)); ?>" 
                           class="text-red-800 hover:text-red-900 font-medium">
                            View Course
                        </a>
                        <form action="<?php echo e(route('students.unenroll', [$student, $course])); ?>" 
                              method="POST" 
                              onsubmit="return confirm('Are you sure you want to unenroll from this course?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" 
                                    class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition">
                                Unenroll
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>

<div class="bg-white rounded-lg shadow-lg p-6">
    <h2 class="text-2xl font-bold text-gray-800 mb-4">Enroll in a New Course</h2>
    
    <?php if($availableCourses->isEmpty()): ?>
        <p class="text-gray-500 text-center py-8">No available courses to enroll in.</p>
    <?php else: ?>
        <form action="<?php echo e(route('students.enroll', $student)); ?>" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div>
                <label for="course_id" class="block text-sm font-medium text-gray-700 mb-2">
                    Select a Course
                </label>
                <select name="course_id" 
                        id="course_id" 
                        required
                        class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent">
                    <option value="">-- Choose a course --</option>
                    <?php $__currentLoopData = $availableCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($course->id); ?>" 
                                <?php if($course->isFull()): ?> disabled <?php endif; ?>>
                            <?php echo e($course->course_code); ?> - <?php echo e($course->course_name); ?>

                            (<?php echo e($course->students->count()); ?>/<?php echo e($course->capacity); ?> enrolled)
                            <?php if($course->isFull()): ?> - FULL <?php endif; ?>
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" 
                    class="bg-red-800 text-white px-6 py-2 rounded-lg hover:bg-red-900 transition">
                Enroll in Course
            </button>
        </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\VERDIDA_IT15_ENROLLMENT_SYSTEM\resources\views/students/show.blade.php ENDPATH**/ ?>