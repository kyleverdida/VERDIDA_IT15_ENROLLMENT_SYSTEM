<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Mini Academic Portal'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <nav class="bg-red-800 text-white shadow-lg">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-8">
                    <a href="/" class="text-2xl font-bold">Mini Academic Portal</a>
                    <div class="flex space-x-4">
                        <a href="<?php echo e(route('students.index')); ?>" 
                           class="hover:bg-red-900 px-3 py-2 rounded transition">
                            Students
                        </a>
                        <a href="<?php echo e(route('courses.index')); ?>" 
                           class="hover:bg-red-900 px-3 py-2 rounded transition">
                            Courses
                        </a>
                    </div>
                </div>
                <div class="flex space-x-3">
                    <a href="<?php echo e(route('students.create')); ?>" 
                       class="bg-white text-red-900 px-4 py-2 rounded font-semibold hover:bg-gray-100 transition">
                        + Add Student
                    </a>
                    <a href="<?php echo e(route('courses.create')); ?>" 
                       class="bg-white text-red-900 px-4 py-2 rounded font-semibold hover:bg-gray-100 transition">
                        + Add Course
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <?php if(session('success')): ?>
        <div class="container mx-auto px-4 mt-4">
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative">
                <span class="block sm:inline"><?php echo e(session('success')); ?></span>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="container mx-auto px-4 mt-4">
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                <span class="block sm:inline"><?php echo e(session('error')); ?></span>
            </div>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="container mx-auto px-4 mt-4">
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                <strong class="font-bold">Validation Error!</strong>
                <ul class="mt-2 list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>

    <main class="container mx-auto px-4 py-8">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="bg-gray-800 text-white mt-12">
        <div class="container mx-auto px-4 py-6 text-center">
            <p>&copy; <?php echo e(date('Y')); ?> Mini Academic Portal. Built with Laravel. Built by Verdida.</p>
        </div>
    </footer>
</body>
</html><?php /**PATH C:\laragon\www\VERDIDA_IT15_ENROLLMENT_SYSTEM\resources\views/layouts/app.blade.php ENDPATH**/ ?>